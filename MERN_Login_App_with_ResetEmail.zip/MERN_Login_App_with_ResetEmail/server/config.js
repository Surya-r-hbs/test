export default {
    JWT_SECRET : "<secret>",
    ATLAS_URI: "mongodb+srv://admin:admin123@cluster0.mb5kg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
}